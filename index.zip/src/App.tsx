import React, { useMemo, useState } from "react";
import { User } from "./types/user";
import UserList from "./components/UserList";

const initialUsers: User[] = [
  { id: 1, name: "مهرزاد نیکزاد", job: "فضانورد" },
  { id: 2, name: "سارا محمدی", job: "طراح رابط کاربری" },
  { id: 3, name: "مهدی کریمی", job: "مدیر پروژه" },
  { id: 4, name: "ندا احمدی", job: "تست نرم‌افزار" },
  { id: 5, name: "حسین فرهادی", job: "کارشناس DevOps" },
  { id: 6, name: "مینا قربانی", job: "تحلیلگر داده" },
  { id: 7, name: "رضا شیری", job: "برنامه‌نویس بک‌اند" },
  { id: 8, name: "لاله جعفری", job: "برنامه‌نویس فرانت‌اند" },
  { id: 9, name: "امید صادقی", job: "پشتیبانی" },
  { id: 10, name: "هدا طاهری", job: "منابع انسانی" }
];

export default function App() {
  const [users] = useState<User[]>(initialUsers);
  const [query, setQuery] = useState("");
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [cleared, setCleared] = useState(false); // برای افکت دکمه

  // فیلتر کاربران بر اساس جستجو
  const filteredUsers = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return users;
    const maybeId = Number(q);
    return users.filter((u) => {
      if (!isNaN(maybeId) && String(u.id) === q) return true;
      return u.name.toLowerCase().includes(q);
    });
  }, [users, query]);

  // انتخاب / لغو انتخاب
  const toggleSelect = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  // دکمه پاک کردن با افکت رنگ سبز
  const clearSelection = () => {
    setSelectedIds([]);
    setQuery("");
    setCleared(true);
    setTimeout(() => setCleared(false), 800);
  };

  return (
    <div className="container">
      <h1>لیست کاربران</h1>

      <div className="controls">
        <input
          className="search"
          placeholder="جستجو بر اساس نام یا ID..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <div className="selection-info">
          <span>انتخاب شده: {selectedIds.length}</span>
          <button
            className={`btn ${cleared ? "btn-cleared" : ""}`}
            onClick={clearSelection}
          >
            پاک کردن
          </button>
        </div>
      </div>

      <UserList
        users={filteredUsers}
        selectedIds={selectedIds}
        onToggle={toggleSelect}
      />
    </div>
  );
}
