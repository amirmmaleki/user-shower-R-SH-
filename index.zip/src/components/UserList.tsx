import React from "react";
import { User } from "../types/user";

type Props = {
  users: User[];
  selectedIds: number[];
  onToggle: (id: number) => void;
};

export default function UserList({ users, selectedIds, onToggle }: Props) {
  if (users.length === 0) {
    return <div className="empty">هیچ کاربری پیدا نشد</div>;
  }

  return (
    <ul className="user-list" role="list">
      {users.map(user => {
        const selected = selectedIds.includes(user.id);
        return (
          <li
            key={user.id}
            className={`user-item ${selected ? "selected" : ""}`}
            onClick={() => onToggle(user.id)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onToggle(user.id);
              }
            }}
            aria-pressed={selected}
          >
            <div className="left">
              <div className="avatar">{user.name.split(" ").map(n => n[0]).slice(0,2).join("")}</div>
            </div>
            <div className="info">
              <div className="name">{user.name} <span className="id">#{user.id}</span></div>
              <div className="meta">{user.job} • {user.email}</div>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
